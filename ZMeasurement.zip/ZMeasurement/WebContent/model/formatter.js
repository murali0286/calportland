 sap.ui.define([], function(){
    "use strict";

    return {
        convertDateToString : function(oDate) {
            return oDate.toISOString();
        }
    }
 });
